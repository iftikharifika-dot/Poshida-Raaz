// Mock API for AI text generation (e.g., GPT-4)
export async function generateText(prompt: string): Promise<string> {
  console.log(`[Mock API] Generating text for prompt: ${prompt.substring(0, 50)}...`);
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(`[Generated Text for: ${prompt.substring(0, 30)}...] \nThis is a mock response from the AI text generator. When you connect a real API (like OpenAI), this will be replaced with actual generated content. It would contain the story, script, or prompts requested.`);
    }, 1000);
  });
}

// Mock API for AI image generation (e.g., Midjourney / DALL-E)
export async function generateImage(prompt: string): Promise<string> {
  console.log(`[Mock API] Generating image for prompt: ${prompt}`);
  return new Promise((resolve) => {
    setTimeout(() => {
      // Return a placeholder image URL based on a keyword in the prompt or just a generic one
      const encodedPrompt = encodeURIComponent(prompt.substring(0, 30));
      resolve(`https://placehold.co/1280x720/1a1a2e/ffffff?text=${encodedPrompt}`);
    }, 1500);
  });
}

// Mock API for AI video generation (e.g., Runway / Pika)
export async function generateVideo(imagePromptUrl: string, motionPrompt: string): Promise<string> {
  console.log(`[Mock API] Generating video from image ${imagePromptUrl} with motion: ${motionPrompt}`);
  return new Promise((resolve) => {
    setTimeout(() => {
      // Mock video URL
      resolve('https://www.w3schools.com/html/mov_bbb.mp4'); 
    }, 2000);
  });
}

// Mock API for Text-to-Speech (e.g., ElevenLabs)
export async function generateSpeech(text: string, voiceId: string): Promise<string> {
  console.log(`[Mock API] Generating speech for voice ${voiceId}, text: ${text.substring(0, 30)}...`);
  return new Promise((resolve) => {
    setTimeout(() => {
      // Mock audio URL
      resolve('https://www.w3schools.com/html/horse.mp3');
    }, 1500);
  });
}

// Mock API for YouTube Upload
export async function uploadToYouTube(videoData: {
  title: string;
  description: string;
  videoUrl: string;
  thumbnailUrl: string;
  tags: string[];
}): Promise<{ videoId: string; url: string; status: string }> {
  console.log(`[Mock API] Uploading to YouTube: ${videoData.title}`);
  return new Promise((resolve) => {
    setTimeout(() => {
      const mockId = Math.random().toString(36).substring(2, 13);
      resolve({
        videoId: mockId,
        url: `https://youtube.com/watch?v=${mockId}`,
        status: 'uploaded_draft' // Can be draft, unlisted, public
      });
    }, 2500);
  });
}

// Analytics Mock API
export async function fetchAnalytics(videoId: string): Promise<{ views: number; likes: number; comments: number }> {
    return new Promise((resolve) => {
        setTimeout(() => {
            resolve({
                views: Math.floor(Math.random() * 10000),
                likes: Math.floor(Math.random() * 500),
                comments: Math.floor(Math.random() * 100),
            })
        }, 500);
    })
}
