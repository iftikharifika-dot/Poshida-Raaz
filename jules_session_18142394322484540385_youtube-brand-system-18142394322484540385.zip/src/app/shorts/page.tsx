"use client";

import React, { useState } from 'react';
import { Smartphone, Wand2, ArrowDown, PlayCircle, Share2, Copy } from 'lucide-react';

export default function ShortsGeneratorPage() {
  const [longScript, setLongScript] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);
  const [shortScript, setShortScript] = useState<{
    hook: string;
    scenes: string[];
    cta: string;
  } | null>(null);

  const handleGenerate = () => {
    if (!longScript) return;
    setIsGenerating(true);
    
    // Simulate AI generation process turning long script into short script
    setTimeout(() => {
      setShortScript({
        hook: "[Visual: Close up of a dusty rotary phone ringing. Text on screen: '3 AM Calls from Nowhere...'] Voiceover (Urdu): 'Kya ho agar aapke naye ghar mein ek aisi phone line baje, jo pichle 20 saal se disconnected ho?'",
        scenes: [
          "[Visual: Man looking at the phone in shock] Voiceover: 'Tariq ko ye purana phone mila. Usne check kiya... taar kati hui thi.'",
          "[Visual: Clock striking 3:00 AM] Voiceover: 'Lekin theek 3 baje, wo bajj utha.'",
          "[Visual: Hand trembling, picking up receiver] Voiceover: 'Usne kanpte hathon se receiver uthaya...'",
          "[Visual: Fast montage: Dark shadows, whispers, man looking terrified] Voiceover: 'Aur doosri taraf se aane wali awaz ne uske hosh uda diye... wo awaz usi ki apni thi, jo 10 saal aage se bol raha tha!'"
        ],
        cta: "[Visual: Black screen with 'Watch Full Story'. Text: Link in description/comments] Voiceover: 'Tariq ne phone par khud se kya suna? Poori kahani dekhein humare channel par.'"
      });
      setIsGenerating(false);
    }, 1500);
  };

  return (
    <div className="max-w-5xl mx-auto p-6 space-y-8 pb-20">
      <div className="flex items-center space-x-4 mb-8">
        <Smartphone className="w-10 h-10 text-orange-600" />
        <h1 className="text-4xl font-bold">Shorts Generator</h1>
      </div>

      <div className="grid md:grid-cols-2 gap-8">
        {/* Input Section */}
        <div className="bg-white p-6 rounded-xl border shadow-sm flex flex-col h-[600px]">
          <div className="mb-4">
            <h2 className="text-xl font-bold">Original Story (Long Form)</h2>
            <p className="text-sm text-slate-500 mt-1">Paste your full script or story here. The AI will condense it into a high-retention 60-second format.</p>
          </div>
          
          <textarea 
            value={longScript}
            onChange={e => setLongScript(e.target.value)}
            placeholder="Paste your long story script here..."
            className="flex-1 w-full p-4 border rounded-lg resize-none focus:ring-2 focus:ring-orange-500 focus:border-orange-500 mb-4"
          />
          
          <button 
            onClick={handleGenerate}
            disabled={isGenerating || !longScript}
            className="w-full flex items-center justify-center space-x-2 bg-orange-600 text-white py-3 rounded-lg hover:bg-orange-700 transition disabled:opacity-50"
          >
            {isGenerating ? (
              <>
                <Wand2 className="w-5 h-5 animate-spin" />
                <span>Generating Short Script...</span>
              </>
            ) : (
              <>
                <Wand2 className="w-5 h-5" />
                <span>Convert to Short</span>
              </>
            )}
          </button>
        </div>

        {/* Output Section */}
        <div className="bg-slate-900 text-slate-200 p-6 rounded-xl border border-slate-800 shadow-lg flex flex-col h-[600px] overflow-hidden">
          <div className="mb-6 flex justify-between items-center">
             <h2 className="text-xl font-bold text-white flex items-center">
                <PlayCircle className="w-5 h-5 mr-2 text-orange-500" />
                Generated Short Script
             </h2>
             {shortScript && (
               <button className="text-slate-400 hover:text-white" title="Copy to clipboard">
                 <Copy className="w-5 h-5" />
               </button>
             )}
          </div>
          
          <div className="flex-1 overflow-y-auto pr-2 space-y-6 custom-scrollbar">
            {!shortScript ? (
              <div className="h-full flex flex-col items-center justify-center text-slate-500 space-y-4">
                <ArrowDown className="w-12 h-12 opacity-20" />
                <p className="text-center px-8">Your fast-paced, high-retention Shorts script will appear here, complete with visual cues, voiceover, and a CTA.</p>
              </div>
            ) : (
              <>
                <div className="bg-slate-800/50 p-4 rounded-lg border border-slate-700 border-l-4 border-l-orange-500">
                  <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">0:00-0:05 - The Hook</h3>
                  <p className="text-sm font-medium leading-relaxed">{shortScript.hook}</p>
                </div>

                <div className="space-y-3">
                  <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">0:05-0:50 - Fast Storytelling & Scenes</h3>
                  {shortScript.scenes.map((scene, idx) => (
                    <div key={idx} className="bg-slate-800/30 p-3 rounded-lg border border-slate-700/50">
                      <p className="text-sm leading-relaxed">{scene}</p>
                    </div>
                  ))}
                </div>

                <div className="bg-slate-800/50 p-4 rounded-lg border border-slate-700 border-l-4 border-l-purple-500">
                  <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">0:50-1:00 - Cliffhanger & CTA</h3>
                  <p className="text-sm font-medium leading-relaxed">{shortScript.cta}</p>
                </div>

                <div className="pt-4 mt-4 border-t border-slate-800 flex justify-end">
                   <button className="flex items-center space-x-2 text-sm bg-slate-800 hover:bg-slate-700 px-4 py-2 rounded-md transition">
                     <Share2 className="w-4 h-4" />
                     <span>Send to Production Pipeline</span>
                   </button>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
