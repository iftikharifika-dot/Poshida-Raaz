"use client";

import React, { useState } from 'react';
import { Calendar, LayoutDashboard, Plus, MoreVertical, Play, Eye, MessageSquare, ThumbsUp } from 'lucide-react';
import { format, addDays } from 'date-fns';

type VideoProject = {
  id: string;
  title: string;
  type: 'Long' | 'Short';
  status: 'Ideas' | 'Scripts' | 'Production' | 'Ready' | 'Published';
  date: Date;
  stats?: { views: string; likes: string; comments: string };
};

const initialProjects: VideoProject[] = [
  { id: '1', title: 'The Silent Whisper', type: 'Long', status: 'Ideas', date: new Date() },
  { id: '2', title: 'Room 404', type: 'Short', status: 'Scripts', date: addDays(new Date(), 2) },
  { id: '3', title: 'Shadow in the Mirror', type: 'Long', status: 'Production', date: addDays(new Date(), 5) },
  { id: '4', title: 'The Last Call (Twist Ending)', type: 'Short', status: 'Ready', date: addDays(new Date(), 7) },
  { 
    id: '5', title: 'Aakhri Umeed', type: 'Long', status: 'Published', date: addDays(new Date(), -3),
    stats: { views: '12.4K', likes: '1.2K', comments: '143' }
  },
];

const columns = ['Ideas', 'Scripts', 'Production', 'Ready', 'Published'] as const;

export default function DashboardPage() {
  const [projects] = useState<VideoProject[]>(initialProjects);

  return (
    <div className="max-w-7xl mx-auto p-6 space-y-8 pb-20">
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center space-x-4">
          <LayoutDashboard className="w-10 h-10 text-slate-800" />
          <h1 className="text-4xl font-bold">Content Dashboard</h1>
        </div>
        <button className="flex items-center space-x-2 bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition">
          <Plus className="w-5 h-5" />
          <span>New Project</span>
        </button>
      </div>

      {/* Stats Summary */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        {[
          { label: 'Total Views', value: '45.2K', icon: Eye, color: 'text-blue-500' },
          { label: 'Total Likes', value: '4.8K', icon: ThumbsUp, color: 'text-green-500' },
          { label: 'Total Comments', value: '624', icon: MessageSquare, color: 'text-yellow-500' },
          { label: 'Published Videos', value: '12', icon: Play, color: 'text-red-500' },
        ].map((stat, i) => (
          <div key={i} className="bg-white p-6 rounded-xl border shadow-sm flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-slate-500">{stat.label}</p>
              <p className="text-2xl font-bold mt-1">{stat.value}</p>
            </div>
            <div className={`p-3 rounded-full bg-slate-50 ${stat.color}`}>
              <stat.icon className="w-6 h-6" />
            </div>
          </div>
        ))}
      </div>

      {/* Kanban Board */}
      <div className="flex gap-6 overflow-x-auto pb-4">
        {columns.map(column => (
          <div key={column} className="flex-1 min-w-[300px] bg-slate-50 rounded-xl p-4">
            <h3 className="font-bold text-slate-700 mb-4 flex items-center justify-between">
              {column}
              <span className="bg-slate-200 text-slate-600 px-2 py-0.5 rounded-full text-xs">
                {projects.filter(p => p.status === column).length}
              </span>
            </h3>
            <div className="space-y-4">
              {projects.filter(p => p.status === column).map(project => (
                <div key={project.id} className="bg-white p-4 rounded-lg border shadow-sm cursor-pointer hover:border-slate-300 transition group relative">
                  <div className="absolute top-4 right-2 opacity-0 group-hover:opacity-100 transition">
                    <button className="text-slate-400 hover:text-slate-600"><MoreVertical className="w-4 h-4" /></button>
                  </div>
                  <div className="flex items-center space-x-2 mb-2">
                    <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-1 rounded-sm ${project.type === 'Long' ? 'bg-indigo-100 text-indigo-700' : 'bg-orange-100 text-orange-700'}`}>
                      {project.type}
                    </span>
                  </div>
                  <h4 className="font-semibold text-slate-800 leading-tight mb-3 pr-6">{project.title}</h4>
                  
                  {project.status === 'Published' && project.stats ? (
                    <div className="flex items-center space-x-4 text-xs text-slate-500 border-t pt-3 mt-3">
                      <span className="flex items-center"><Eye className="w-3 h-3 mr-1" /> {project.stats.views}</span>
                      <span className="flex items-center"><ThumbsUp className="w-3 h-3 mr-1" /> {project.stats.likes}</span>
                    </div>
                  ) : (
                    <div className="flex items-center text-xs text-slate-500 border-t pt-3 mt-3">
                      <Calendar className="w-3 h-3 mr-1" />
                      {format(project.date, 'MMM d, yyyy')}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
