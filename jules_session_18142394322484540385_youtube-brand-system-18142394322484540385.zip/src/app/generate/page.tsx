"use client";

import React, { useState } from 'react';
import { Wand2, FileText, Image as ImageIcon, Mic, Film, Upload, CheckCircle2, ChevronRight, Loader2 } from 'lucide-react';
import { generateText, generateImage, generateSpeech, generateVideo, uploadToYouTube } from '@/lib/mock-api';
import Image from 'next/image';

const steps = [
  { id: 'idea', label: 'Idea & Script', icon: FileText },
  { id: 'visuals', label: 'AI Visuals', icon: ImageIcon },
  { id: 'audio', label: 'Voiceover', icon: Mic },
  { id: 'video', label: 'Video Gen', icon: Film },
  { id: 'publish', label: 'Publish', icon: Upload }
];

export default function GeneratePage() {
  const [currentStep, setCurrentStep] = useState(0);
  const [isProcessing, setIsProcessing] = useState(false);
  
  // State for generated content
  const [prompt, setPrompt] = useState("");
  const [script, setScript] = useState("");
  const [imageUrl, setImageUrl] = useState("");
  const [audioUrl, setAudioUrl] = useState("");
  const [videoUrl, setVideoUrl] = useState("");
  const [youtubeData, setYoutubeData] = useState<{videoId?: string, url?: string}>({});

  const handleNextStep = async () => {
    setIsProcessing(true);
    try {
      if (currentStep === 0) {
        // Idea to Script
        const generatedScript = await generateText(`Write an Urdu suspense story script based on: ${prompt}`);
        setScript(generatedScript);
      } else if (currentStep === 1) {
        // Script to Image Prompts (Visuals)
        const img = await generateImage("Cinematic suspense shot, dark lighting, mystery");
        setImageUrl(img);
      } else if (currentStep === 2) {
        // Audio Gen
        const audio = await generateSpeech(script, "tariq_voice_id");
        setAudioUrl(audio);
      } else if (currentStep === 3) {
        // Video Gen
        const video = await generateVideo(imageUrl, "Slow zoom in on the subject");
        setVideoUrl(video);
      } else if (currentStep === 4) {
        // Publish
        const res = await uploadToYouTube({
          title: "New Suspense Story",
          description: script.substring(0, 100),
          videoUrl,
          thumbnailUrl: imageUrl,
          tags: ["Urdu", "Suspense"]
        });
        setYoutubeData(res);
      }
      
      setCurrentStep(prev => Math.min(prev + 1, steps.length - 1));
    } catch (error) {
      console.error("Error processing step:", error);
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="max-w-5xl mx-auto p-6 space-y-8 pb-20">
      <div className="flex items-center space-x-4 mb-8">
        <Wand2 className="w-10 h-10 text-purple-600" />
        <h1 className="text-4xl font-bold">Content Generator pipeline</h1>
      </div>

      {/* Progress Bar */}
      <div className="flex items-center justify-between relative mb-12">
        <div className="absolute left-0 top-1/2 -translate-y-1/2 w-full h-1 bg-slate-200 -z-10"></div>
        {steps.map((step, index) => {
          const isActive = index === currentStep;
          const isCompleted = index < currentStep;
          
          return (
            <div key={step.id} className="flex flex-col items-center">
              <div className={`w-12 h-12 rounded-full flex items-center justify-center border-4 ${
                isActive ? 'bg-purple-600 border-purple-200 text-white' : 
                isCompleted ? 'bg-green-500 border-green-200 text-white' : 
                'bg-white border-slate-200 text-slate-400'
              }`}>
                {isCompleted ? <CheckCircle2 className="w-6 h-6" /> : <step.icon className="w-5 h-5" />}
              </div>
              <span className={`mt-2 text-sm font-medium ${isActive ? 'text-purple-700' : 'text-slate-500'}`}>
                {step.label}
              </span>
            </div>
          )
        })}
      </div>

      {/* Main Content Area */}
      <div className="bg-white rounded-xl border shadow-sm p-8 min-h-[400px]">
        {currentStep === 0 && (
          <div className="space-y-6">
            <h2 className="text-2xl font-bold">Step 1: Idea to Script</h2>
            <p className="text-slate-500">Enter a short idea or premise. The AI will generate a complete Urdu suspense script, scene breakdown, and metadata.</p>
            <textarea 
              value={prompt}
              onChange={e => setPrompt(e.target.value)}
              placeholder="e.g. A man finds an old rotary phone in his new house. It shouldn't be connected, but it rings at exactly 3 AM every night..."
              className="w-full h-32 p-4 border rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
            />
            {script && (
              <div className="mt-6">
                <h3 className="font-semibold mb-2">Generated Script Preview:</h3>
                <div className="p-4 bg-slate-50 border rounded-lg whitespace-pre-wrap text-sm text-slate-700 max-h-60 overflow-y-auto">
                  {script}
                </div>
              </div>
            )}
          </div>
        )}

        {currentStep === 1 && (
          <div className="space-y-6">
            <h2 className="text-2xl font-bold">Step 2: Generate Visuals (Thumbnails &amp; Scenes)</h2>
            <p className="text-slate-500">The system has extracted visual prompts from your script. Generate images for the scenes.</p>
            <div className="p-4 bg-slate-50 rounded-lg border">
               <p className="text-sm font-medium mb-2">Scene 1 Prompt:</p>
               <p className="text-xs text-slate-600 mb-4">&quot;Cinematic wide shot, dark room, single dusty rotary phone on a table, 3 AM moonlight shining through window. Suspenseful, photorealistic, 8k.&quot;</p>
               {imageUrl && (
                 <div className="mt-4 relative w-full max-w-md h-64">
                   <Image src={imageUrl} alt="Generated visual" fill className="rounded-lg shadow-md object-cover" unoptimized />
                 </div>
               )}
            </div>
          </div>
        )}

        {currentStep === 2 && (
          <div className="space-y-6">
            <h2 className="text-2xl font-bold">Step 3: Generate Voiceover</h2>
            <p className="text-slate-500">Convert the Urdu script into natural-sounding speech using selected character voices.</p>
            {audioUrl && (
              <div className="p-6 bg-slate-50 border rounded-lg flex flex-col items-center justify-center space-y-4 mt-8">
                <Mic className="w-12 h-12 text-slate-400" />
                <audio controls className="w-full max-w-md">
                  <source src={audioUrl} type="audio/mpeg" />
                  Your browser does not support the audio element.
                </audio>
              </div>
            )}
          </div>
        )}

        {currentStep === 3 && (
          <div className="space-y-6">
             <h2 className="text-2xl font-bold">Step 4: Generate Video (Image-to-Video)</h2>
             <p className="text-slate-500">Animate the generated scenes using AI video generation.</p>
             {videoUrl && (
               <div className="mt-6 aspect-video bg-black rounded-lg overflow-hidden relative flex items-center justify-center">
                 <video controls className="w-full h-full">
                   <source src={videoUrl} type="video/mp4" />
                   Your browser does not support the video tag.
                 </video>
               </div>
             )}
          </div>
        )}

        {currentStep === 4 && (
          <div className="space-y-6">
            <h2 className="text-2xl font-bold">Step 5: Review &amp; Publish to YouTube</h2>
            <p className="text-slate-500">Review all metadata before uploading.</p>
            
            {youtubeData.videoId ? (
               <div className="p-8 bg-green-50 border border-green-200 rounded-lg text-center space-y-4">
                 <div className="w-16 h-16 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto mb-4">
                   <CheckCircle2 className="w-8 h-8" />
                 </div>
                 <h3 className="text-xl font-bold text-green-800">Successfully Uploaded!</h3>
                 <p className="text-green-700">Video ID: {youtubeData.videoId}</p>
                 <a href={youtubeData.url} target="_blank" rel="noreferrer" className="inline-block mt-4 text-blue-600 underline">View on YouTube</a>
               </div>
            ) : (
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Title</label>
                    <input type="text" defaultValue="The Mystery of 3 AM | Urdu Suspense Story" className="w-full p-2 border rounded" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Tags</label>
                    <input type="text" defaultValue="Urdu Story, Suspense, Mystery, Poshida Raaz" className="w-full p-2 border rounded" />
                  </div>
                </div>
                <div className="space-y-2">
                    <label className="text-sm font-medium">Description</label>
                    <textarea defaultValue="A man finds an old rotary phone..." className="w-full p-2 border rounded h-24" />
                </div>
              </div>
            )}
          </div>
        )}

        {/* Navigation Buttons */}
        <div className="flex justify-end mt-12 pt-6 border-t">
          {currentStep < steps.length && !youtubeData.videoId && (
            <button 
              onClick={handleNextStep}
              disabled={isProcessing || (currentStep === 0 && !prompt)}
              className="flex items-center space-x-2 bg-purple-600 text-white px-6 py-3 rounded-lg hover:bg-purple-700 transition disabled:opacity-50"
            >
              {isProcessing ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  <span>Processing...</span>
                </>
              ) : (
                <>
                  <span>{currentStep === 0 && script ? 'Move to Visuals' : currentStep === steps.length - 1 ? 'Upload to YouTube' : 'Generate & Continue'}</span>
                  <ChevronRight className="w-5 h-5" />
                </>
              )}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
