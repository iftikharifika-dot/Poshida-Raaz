"use client";

import React, { useState } from 'react';
import { Users, Plus, Save, Trash2, Edit } from 'lucide-react';
import { v4 as uuidv4 } from 'uuid';

type Character = {
  id: string;
  name: string;
  age: string;
  gender: string;
  appearance: string;
  clothing: string;
  hair: string;
  personality: string;
  voice: string;
};

const initialCharacters: Character[] = [
  {
    id: "1",
    name: "Tariq Ali",
    age: "45",
    gender: "Male",
    appearance: "Tall, slightly weathered face, piercing brown eyes, short stubble.",
    clothing: "Usually wears a dark brown leather jacket over a simple shalwar kameez or dark button-down shirt.",
    hair: "Salt and pepper, neatly combed back.",
    personality: "Stoic, observant, carries a hidden guilt. Rarely smiles.",
    voice: "Deep, calm, slight gravel, slow and deliberate pacing."
  },
  {
    id: "2",
    name: "Sana",
    age: "28",
    gender: "Female",
    appearance: "Pale skin, expressive large dark eyes, often looks tired or anxious.",
    clothing: "Modest pastel-colored kurtas, often wears a plain dupatta draped over one shoulder.",
    hair: "Long, dark brown, usually tied in a loose low bun.",
    personality: "Nervous but highly intelligent, notices small details others miss. Protective.",
    voice: "Soft, clear, tends to speak quickly when nervous."
  }
];

export default function CharactersPage() {
  const [characters, setCharacters] = useState<Character[]>(initialCharacters);
  const [isEditing, setIsEditing] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  
  const [formData, setFormData] = useState<Omit<Character, 'id'>>({
    name: '', age: '', gender: 'Male', appearance: '', clothing: '', hair: '', personality: '', voice: ''
  });

  const handleAddNew = () => {
    setFormData({
      name: '', age: '', gender: 'Male', appearance: '', clothing: '', hair: '', personality: '', voice: ''
    });
    setEditingId(null);
    setIsEditing(true);
  };

  const handleEdit = (char: Character) => {
    setFormData(char);
    setEditingId(char.id);
    setIsEditing(true);
  };

  const handleDelete = (id: string) => {
    setCharacters(characters.filter(c => c.id !== id));
  };

  const handleSave = () => {
    if (!formData.name) return;

    if (editingId) {
      setCharacters(characters.map(c => c.id === editingId ? { ...formData, id: editingId } : c));
    } else {
      setCharacters([...characters, { ...formData, id: uuidv4() }]);
    }
    setIsEditing(false);
  };

  return (
    <div className="max-w-6xl mx-auto p-6 space-y-8 pb-20">
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center space-x-4">
          <Users className="w-10 h-10 text-slate-800" />
          <h1 className="text-4xl font-bold">Character Database</h1>
        </div>
        {!isEditing && (
          <button 
            onClick={handleAddNew}
            className="flex items-center space-x-2 bg-slate-900 text-white px-4 py-2 rounded-lg hover:bg-slate-800 transition"
          >
            <Plus className="w-5 h-5" />
            <span>Add Character</span>
          </button>
        )}
      </div>

      {isEditing ? (
        <div className="bg-white p-6 rounded-xl border shadow-sm space-y-6">
          <h2 className="text-2xl font-bold">{editingId ? 'Edit Character' : 'New Character'}</h2>
          
          <div className="grid md:grid-cols-3 gap-6">
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-700">Name</label>
              <input 
                type="text" 
                value={formData.name}
                onChange={e => setFormData({...formData, name: e.target.value})}
                className="w-full p-2 border rounded-md"
                placeholder="e.g. Tariq"
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-700">Age</label>
              <input 
                type="text" 
                value={formData.age}
                onChange={e => setFormData({...formData, age: e.target.value})}
                className="w-full p-2 border rounded-md"
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-700">Gender</label>
              <select 
                value={formData.gender}
                onChange={e => setFormData({...formData, gender: e.target.value})}
                className="w-full p-2 border rounded-md"
              >
                <option>Male</option>
                <option>Female</option>
              </select>
            </div>
          </div>

          <div className="space-y-4">
             <div className="space-y-2">
              <label className="text-sm font-medium text-slate-700">Face &amp; Body Appearance</label>
              <textarea 
                value={formData.appearance}
                onChange={e => setFormData({...formData, appearance: e.target.value})}
                className="w-full p-2 border rounded-md h-20"
                placeholder="Prompt friendly description..."
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-700">Clothing Style</label>
              <textarea 
                value={formData.clothing}
                onChange={e => setFormData({...formData, clothing: e.target.value})}
                className="w-full p-2 border rounded-md h-20"
              />
            </div>
             <div className="space-y-2">
              <label className="text-sm font-medium text-slate-700">Hair Style</label>
              <input 
                type="text"
                value={formData.hair}
                onChange={e => setFormData({...formData, hair: e.target.value})}
                className="w-full p-2 border rounded-md"
              />
            </div>
             <div className="space-y-2">
              <label className="text-sm font-medium text-slate-700">Personality Traits</label>
              <textarea 
                value={formData.personality}
                onChange={e => setFormData({...formData, personality: e.target.value})}
                className="w-full p-2 border rounded-md h-20"
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-700">Voice Description (for AI TTS)</label>
              <textarea 
                value={formData.voice}
                onChange={e => setFormData({...formData, voice: e.target.value})}
                className="w-full p-2 border rounded-md h-20"
                placeholder="e.g. Deep, raspy, calm..."
              />
            </div>
          </div>

          <div className="flex space-x-4 pt-4">
            <button 
              onClick={handleSave}
              className="flex items-center space-x-2 bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition"
            >
              <Save className="w-5 h-5" />
              <span>Save Character</span>
            </button>
            <button 
              onClick={() => setIsEditing(false)}
              className="px-6 py-2 rounded-lg border hover:bg-slate-50 transition"
            >
              Cancel
            </button>
          </div>
        </div>
      ) : (
        <div className="grid md:grid-cols-2 gap-6">
          {characters.map(char => (
            <div key={char.id} className="bg-white p-6 rounded-xl border shadow-sm hover:shadow-md transition group relative">
              <div className="absolute top-4 right-4 flex space-x-2 opacity-0 group-hover:opacity-100 transition">
                <button onClick={() => handleEdit(char)} className="p-2 bg-slate-100 text-slate-600 rounded-md hover:text-blue-600">
                  <Edit className="w-4 h-4" />
                </button>
                <button onClick={() => handleDelete(char.id)} className="p-2 bg-slate-100 text-slate-600 rounded-md hover:text-red-600">
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>

              <div className="flex items-center space-x-4 mb-4">
                <div className="w-16 h-16 bg-slate-200 rounded-full flex items-center justify-center text-xl font-bold text-slate-500">
                  {char.name.charAt(0)}
                </div>
                <div>
                  <h3 className="text-2xl font-bold">{char.name}</h3>
                  <p className="text-slate-500">{char.age} yrs • {char.gender}</p>
                </div>
              </div>

              <div className="space-y-3 mt-6">
                <div>
                  <h4 className="text-xs font-bold text-slate-400 uppercase">Appearance Prompt (AI Image)</h4>
                  <p className="text-sm text-slate-700 mt-1 bg-slate-50 p-2 rounded border border-slate-100">
                    {char.appearance} {char.hair} Wears: {char.clothing}
                  </p>
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-400 uppercase">Personality</h4>
                  <p className="text-sm text-slate-700 mt-1">{char.personality}</p>
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-400 uppercase">Voice (AI Audio)</h4>
                  <p className="text-sm text-slate-700 mt-1">{char.voice}</p>
                </div>
              </div>
            </div>
          ))}
          {characters.length === 0 && (
             <div className="col-span-2 text-center py-12 text-slate-500">
               No characters added yet. Click &quot;Add Character&quot; to start.
             </div>
          )}
        </div>
      )}
    </div>
  );
}
