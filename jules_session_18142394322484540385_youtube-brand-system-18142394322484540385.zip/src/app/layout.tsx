import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import Link from 'next/link';
import { LayoutDashboard, Users, Wand2, Smartphone, Video } from 'lucide-react';

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "Poshida Raaz | Brand System",
  description: "Content management system for Poshida Raaz YouTube Channel",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={`${inter.className} bg-slate-50 text-slate-900 flex h-screen overflow-hidden`}>
        {/* Sidebar */}
        <aside className="w-64 bg-slate-900 text-slate-300 flex flex-col flex-shrink-0">
          <div className="p-6">
            <h2 className="text-2xl font-bold text-white tracking-tight">Poshida Raaz</h2>
            <p className="text-xs text-slate-400 mt-1 uppercase tracking-wider">Content System</p>
          </div>
          
          <nav className="flex-1 px-4 space-y-2 mt-4">
            <Link href="/" className="flex items-center space-x-3 px-4 py-3 rounded-lg hover:bg-slate-800 hover:text-white transition">
              <LayoutDashboard className="w-5 h-5" />
              <span>Dashboard</span>
            </Link>
            <Link href="/brand" className="flex items-center space-x-3 px-4 py-3 rounded-lg hover:bg-slate-800 hover:text-white transition">
              <Video className="w-5 h-5" />
              <span>Brand Identity</span>
            </Link>
            <Link href="/characters" className="flex items-center space-x-3 px-4 py-3 rounded-lg hover:bg-slate-800 hover:text-white transition">
              <Users className="w-5 h-5" />
              <span>Characters</span>
            </Link>
            <Link href="/generate" className="flex items-center space-x-3 px-4 py-3 rounded-lg hover:bg-slate-800 hover:text-white transition">
              <Wand2 className="w-5 h-5" />
              <span>Generate (Long)</span>
            </Link>
            <Link href="/shorts" className="flex items-center space-x-3 px-4 py-3 rounded-lg hover:bg-slate-800 hover:text-white transition">
              <Smartphone className="w-5 h-5" />
              <span>Shorts Generator</span>
            </Link>
          </nav>

          <div className="p-4 border-t border-slate-800">
             <div className="flex items-center space-x-3">
               <div className="w-8 h-8 rounded-full bg-slate-700 flex items-center justify-center text-sm font-bold text-white">PR</div>
               <div className="text-sm">
                 <p className="font-medium text-white">Admin</p>
                 <p className="text-slate-500 text-xs">Poshida Raaz</p>
               </div>
             </div>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 overflow-y-auto">
          {children}
        </main>
      </body>
    </html>
  );
}
