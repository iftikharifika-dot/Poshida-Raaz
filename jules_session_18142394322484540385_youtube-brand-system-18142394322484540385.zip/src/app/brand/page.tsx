import React from 'react';
import { Video, Image as ImageIcon, Palette, Type } from 'lucide-react';

export default function BrandPage() {
  const channelNameOptions = [
    "Poshida Raaz (پوشیدہ راز - Hidden Secrets)",
    "Urdu Suspense Hub",
    "Khamosh Kahaniyan (خاموش کہانیاں - Silent Stories)",
    "Anjaam (انجام - The Ending)",
    "Siyah Raat (سیاہ رات - Dark Night)",
    "Raaz-e-Hasti (راز ہستی - Secrets of Existence)",
    "Gumshuda Sach (گمشدہ سچ - The Lost Truth)",
    "Aakhri Umeed (آخری امید - The Last Hope)",
    "Wahm (وہم - Illusion)",
    "Tilismi Duniya (طلسمی دنیا - Magical World)"
  ];

  return (
    <div className="max-w-5xl mx-auto p-6 space-y-8 pb-20">
      <div className="flex items-center space-x-4 mb-8">
        <Video className="w-10 h-10 text-red-600" />
        <h1 className="text-4xl font-bold">Brand Identity & Strategy</h1>
      </div>

      {/* Selected Brand Section */}
      <section className="bg-slate-900 rounded-xl p-8 border border-slate-800 text-white shadow-lg">
        <div className="grid md:grid-cols-2 gap-8">
          <div>
            <h2 className="text-sm font-semibold text-slate-400 uppercase tracking-wider mb-2">Selected Direction</h2>
            <h3 className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-red-500 to-orange-500 mb-2">
              Poshida Raaz
            </h3>
            <p className="text-xl text-slate-300 font-urdu mb-4">پوشیدہ راز</p>
            
            <div className="space-y-4 mt-8">
              <div>
                <p className="text-sm text-slate-400">Handle</p>
                <p className="font-mono text-lg text-slate-200">@PoshidaRaazStories</p>
              </div>
              <div>
                <p className="text-sm text-slate-400">Slogan</p>
                <p className="text-lg italic text-slate-200">&quot;Har kahani mein ek raaz hai...&quot; (ہر کہانی میں ایک راز ہے)</p>
              </div>
            </div>
          </div>

          <div className="bg-slate-800/50 p-6 rounded-lg">
            <h4 className="font-semibold mb-4 text-slate-200">About Section (Urdu)</h4>
            <div className="text-right font-urdu text-lg leading-relaxed text-slate-300" dir="rtl">
              خوش آمدید! &apos;پوشیدہ راز&apos; وہ جگہ ہے جہاں سسپنس، جذبات اور اسرار آپس میں ملتے ہیں۔ ہم آپ کے لیے لاتے ہیں اوریجنل اردو کہانیاں اور شارٹ فلمز جن کا اختتام آپ کو حیران کر دے گا۔ ہر ہفتے نئی کہانی، نئے کردار، اور ایک نیا راز۔ ہمارے ساتھ جڑیں اور اس پراسرار سفر کا حصہ بنیں۔
            </div>
            <div className="mt-4 pt-4 border-t border-slate-700">
              <h4 className="font-semibold mb-2 text-sm text-slate-400">English Translation:</h4>
              <p className="text-sm text-slate-400 italic">
                Welcome! &apos;Poshida Raaz&apos; (Hidden Secrets) is where suspense, emotion, and mystery meet. We bring you original Urdu stories and short films with endings that will leave you amazed. A new story, new characters, and a new secret every week. Join us and be a part of this mysterious journey.
              </p>
            </div>
          </div>
        </div>
      </section>

      <div className="grid md:grid-cols-2 gap-8">
        {/* Name Options */}
        <section className="bg-white p-6 rounded-xl border shadow-sm">
          <h2 className="text-xl font-bold mb-4 flex items-center">
            <Type className="w-5 h-5 mr-2 text-slate-500" />
            Top 10 Name Concepts
          </h2>
          <ul className="space-y-3">
            {channelNameOptions.map((name, index) => (
              <li key={index} className={`p-3 rounded-md ${index === 0 ? 'bg-red-50 border border-red-200 font-medium' : 'bg-slate-50'}`}>
                {index + 1}. {name}
                {index === 0 && <span className="ml-2 text-xs bg-red-100 text-red-600 px-2 py-1 rounded-full">Selected</span>}
              </li>
            ))}
          </ul>
        </section>

        {/* Visual Identity */}
        <section className="space-y-6">
          <div className="bg-white p-6 rounded-xl border shadow-sm">
            <h2 className="text-xl font-bold mb-4 flex items-center">
              <Palette className="w-5 h-5 mr-2 text-slate-500" />
              Visual Identity
            </h2>
            <div className="space-y-4">
              <div>
                <h3 className="font-semibold text-slate-700">Color Palette</h3>
                <div className="flex mt-2 space-x-2">
                  <div className="w-12 h-12 rounded-md bg-[#0F172A]" title="Deep Slate (Backgrounds)"></div>
                  <div className="w-12 h-12 rounded-md bg-[#7F1D1D]" title="Dark Red (Accents/Suspense)"></div>
                  <div className="w-12 h-12 rounded-md bg-[#D97706]" title="Amber (Highlights/Mystery)"></div>
                  <div className="w-12 h-12 rounded-md bg-[#E2E8F0]" title="Light Slate (Text)"></div>
                </div>
              </div>
              <div>
                <h3 className="font-semibold text-slate-700">Typography</h3>
                <p className="text-sm text-slate-600">English: Inter / Montserrat (Clean, modern)</p>
                <p className="text-sm text-slate-600">Urdu: Jameel Noori Nastaleeq / Noto Nastaliq Urdu (Classic, readable)</p>
              </div>
              <div>
                <h3 className="font-semibold text-slate-700">Vibe</h3>
                <p className="text-sm text-slate-600">Cinematic, moody lighting, high contrast, mysterious silhouettes.</p>
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-xl border shadow-sm">
            <h2 className="text-xl font-bold mb-4 flex items-center">
              <ImageIcon className="w-5 h-5 mr-2 text-slate-500" />
              Logo &amp; Banner Concept
            </h2>
            <div className="space-y-4">
              <div>
                <h3 className="font-semibold text-slate-700">Profile Logo</h3>
                <p className="text-sm text-slate-600">A minimalist keyhole or a half-hidden face in shadows, glowing with amber light against a dark background. Very clean, works well at small sizes.</p>
              </div>
              <div>
                <h3 className="font-semibold text-slate-700">Channel Banner</h3>
                <p className="text-sm text-slate-600">A cinematic wide shot of an empty, dimly lit street or a vintage room. Text: &quot;Poshida Raaz&quot; in English and Urdu, centered. Subtitle: &quot;New Suspense Story Every Week&quot;.</p>
              </div>
              <div>
                 <h3 className="font-semibold text-slate-700">Thumbnail Style</h3>
                 <p className="text-sm text-slate-600">High contrast close-up of a character&apos;s expressive face (fear, shock, realization). Bold, large Urdu text (max 3-4 words). Subtle red or amber glow framing the subject.</p>
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
